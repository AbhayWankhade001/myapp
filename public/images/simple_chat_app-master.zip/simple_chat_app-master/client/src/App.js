import ChatContainer from "./components/ChatContainer.js";


function App() {
  return (
    <div style={{backgroundColor: "#ece5dd" , maxHeight:"100%" , padding:10}} >
      <ChatContainer/>
    </div>
  );
}

export default App;
